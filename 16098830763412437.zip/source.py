import hashlib
import csv

def hash_password_hack(input_file_name, output_file_name):
     with open(input_file_name, 'r') as csvfile:
        
        reader = csv.reader(csvfile)
        
        final=[]
        
        for row in reader:
            name = row[0]
            passw=row[1]
            
            for i in range(1000,9999):
                word=str(i)
                obj = hashlib.sha256()
                obj.update(word.encode())
                h = obj.hexdigest()
                
                if h == passw:
                    final.append([name,word])
                        
                with open (output_file_name,'w',newline="") as file:
                     writer = csv.writer(file)
                     for item in final:
                         writer.writerow(item)



                     
                     
       

