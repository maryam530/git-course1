import csv
# For the average
from statistics import mean
from operator import itemgetter, attrgetter
def calculate_averages(input_file_name, output_file_name):
     with open(input_file_name, 'r') as csvfile:
         reader = csv.reader(csvfile)
         list_grade=[]
         for row in reader:
             name=row[0]
             grade_mean = (float(grade) for grade in row[1:])
             list_grade.append([row[0], mean(grade_mean)])
     with open (output_file_name,'w',newline="") as file:
          writer = csv.writer(file)
          for item in  list_grade:
               writer.writerow(item)
            
def calculate_sorted_averages(input_file_name, output_file_name):
     with open(input_file_name, 'r') as csvfile:
        reader = csv.reader(csvfile)
        list_grade=[]
        final=[]
        list_name=[]
        dic1={}
        for row in reader:
            name=row[0]
            grade_mean = (float(grade) for grade in row[1:])
            list_grade.append( mean(grade_mean)) 
            
            list_name.append(row[0])
     dic1=dict(zip(list_name, list_grade))
     top=list(dic1.items())
        
       
     kopy=sorted(top, key=itemgetter(1,0))
     
        
     with open (output_file_name,'w',newline="") as file:
          
          writer = csv.writer(file)
          for item in  kopy:
               writer.writerow(item)
def calculate_three_best(input_file_name, output_file_name):
     with open(input_file_name, 'r') as csvfile:
        
        reader = csv.reader(csvfile)
        list_grade=[]
        
        list_name=[]
        dic1={}
        kopy1=[]
        for row in reader:
            name=row[0]
            grade_mean = (float(grade) for grade in row[1:])
            list_grade.append( mean(grade_mean)) 
            
            list_name.append(row[0])
     dic1=dict(zip(list_name, list_grade))
     top=list(dic1.items())
        
     kopy=sorted(top, key=itemgetter(1,0))
               
     for i in range(1,4):
                    kopy1.append(kopy[len(kopy)-i])
                    kopy2=sorted(kopy1, key=itemgetter(1,0))
     with open (output_file_name,'w',newline="") as file:
          writer = csv.writer(file)
          for item in kopy2:
               writer.writerow(item)

def calculate_three_worst(input_file_name, output_file_name):
     with open(input_file_name, 'r') as csvfile:
        reader = csv.reader(csvfile)
        list_grade=[]
       
        list_name=[]
        
        finalworse=[]
        
        for row in reader:
            name=row[0]
            grade_mean = (float(grade) for grade in row[1:]) 
            
            list_name.append(row[0])
            list_grade.append( mean(grade_mean)) 
            
     
     kopy=sorted(list_grade)
     for i in range(0,3):
          finalworse.append(kopy[i])
    
     with open (output_file_name,'w',newline="") as file:
          writer = csv.writer(file)
          for item in  finalworse:
               writer.writerow([item])

def calculate_average_of_averages(input_file_name, output_file_name):
      with open(input_file_name, 'r') as csvfile:
          reader = csv.reader(csvfile)
          
          list_grade=[]
          for row in reader:
              name=row[0]
              grade_mean = (float(grade) for grade in row[1:])
              list_grade.append( mean(grade_mean))
          final=mean(list_grade)
          final1=str(final)
      with open (output_file_name,'w',newline="") as file:
        writer = csv.writer(file)
        writer.writerow([final1])
